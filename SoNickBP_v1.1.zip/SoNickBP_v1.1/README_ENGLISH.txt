************** xCris_18  **************
UNTETHERED SERVICE BY @SoNick_14

ONLY MAC! (Soon there will be in Windows)
****** REGISTER YOUR SERIAL NUMBER https://sonick14.tech/service.html **************

NOTE:
- If you are already registered, you can do the bypass as many times as you want in the same iDevice, YOU ONLY NEED JAILBREAK.
- If you have already bypassed with a previous version (v6, v5 ..), REMOVE THE SIMCARD AND CLOSE SESSION IN iCLOUD before starting with this version and start from step 1.
- Don't enter the iCloud account until all the steps are done!
- The simcard with PIN / PUK lock is used to keep the bypass untethered on GSM / MEID devices, NOT FOR DATA !!


===================== UNTETHERED BYPASS =====================
    It's important that your iDevice has Jailbreak:
	1) JB with Checkra1n (CLI Mode or GUI)
		- Close the checkra1n window after jailbreak!

	2)   CONNECT TO A WIFI NETWORK

	3)   Double-click the "sonickBP.app" application and select "Activate device".
		- Wait a few seconds and receive the following notice:
			[*] Bypass without ties done!

 ~ DO THIS STEP ONLY IF YOU HAVE AN IPHONE OR IPAD GSM (iDevices with SIM input)
"""""""""""""""" FOR iPHONE / iPAD GSM ONLY """"""""""""""""""""
	7) After the Respring a "SoNick_14 Untethered" message appears: 
	- Insert the SIM card with PIN lock and then OK in the message.
	- Swipe down or cancel "SIM Card Locked"
	   (Always do this when that window comes out)

DONE!

=============================================================================
IMPORTANT:
- Wifi devices (iPod and iPad), the Untethered procedure ends in step 6.

- It's necessary to have the SIM locked with PIN always on the iPhone for the Untethered to work.

- iOS 13.5.1 use checkra1n 0.10.2, and go to OPTIONS, enable "ALLOW UNTESTED iOS".

- A7, A8, A8X use checkra1n 0.10.0, and go to OPTIONS, enable "SAFE MODE" and "ALLOW UNTESTED iOS".

- In case you remove the SIM, the iDevice will return to the activation lock. The solution to this is to turn off the iPhone and enter a SIM with PIN and then turn on the iPhone.

- DON'T ENTER THE SIM PIN CODE, Always close this window after each restart.
=============================================================================