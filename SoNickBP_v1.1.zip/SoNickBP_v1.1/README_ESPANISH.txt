﻿************** xCris_18  **************
UNTETHERED SERVICE BY @SoNick_14

SOLO MAC! (Pronto habra en Windows)
*** REGISTRA TU NUMERO DE SERIE ANTES DE EMPEZAR https://sonick14.tech/service.html ***

NOTA:
- Si ya estas registrado, puedes hacer el bypass cuantas veces quieras en el mismo iDevice, SOLO NECESITAS JAILBREAK.
- Si ya realizaste el bypass con una version anterior (v6, v5..), RETIRA LA SIMCARD Y CIERRA SESION EN iCLOUD antes de empezar con esta version y empieza desde el paso 1.
- Ingresar la cuenta de iCloud luego de configurar el Setup!!!
- La simcard con bloqueo de PIN/PUK sirve para mantener el bypass untethered en dispositivos GSM/MEID, NO PARA DATOS!!

===================== UNTETHERED BYPASS =====================
    Es importante que tu iDeviEe tenga Jailbreak:
	1) JailBreak usando Checkra1n (CLI Mode o GUI)
		- Cierra la ventana del checkra1n luego del jailbreak!

	2) Conectese a una RED WIFI.

	3) Doble click a la app "sonickBP.app" y seleccione "Activate Device".
		- Espere unos segundos y aparecerá el siguiente aviso:
		      [*]Untethered Bypass Done!

~ REALIZA ESTE PASO SOLO SI TIENES UN IPHONE O IPAD GSM (iDevices con entrada de SIM)
"""""""""""""""" SOLO PARA iPHONE / iPAD GSM """"""""""""""""""""
	4) Luego del Respring aparecerá un mensaje "SoNick_14 Untethered":
	- Inserta la tarjeta SIM con bloqueo de PIN y luego OK en el mensaje.
	- Deslizar hacia abajo o cancelar "Tarjeta SIM Bloqueada"
	   (Siempre hacer esto cuando salga esa ventana)

LISTO!

=============================================================================
IMPORTANTE:
- Dispositivos (iPod Touch y iPad Wifi), el procedimiento Untethered es instantáneo.

- Es necesario tener la SIM bloqueada con PIN siempre en el iPhone para que funcione el Untethered.

- iOS 13.5.1. use checkra1n 0.10.2, vaya a OPTIONS, luego habilite "ALLOW UNTESTED iOS".

- A7, A8, A8X use checkra1n 0.10.0, vaya a OPTIONS, luego habilite "SAFE MODE" y "ALLOW UNTESTED iOS".

- En caso de que quites la SIM, el iDevice volverá al bloqueo de activación. La solución a esto es apagar el iPhone e introducir una SIM con PIN y luego encender el iPhone.

- NO INGRESAR EL CODIGO PIN DE LA SIM!!! Siempre cerrar esta ventana luego de cada reinicio.
=============================================================================